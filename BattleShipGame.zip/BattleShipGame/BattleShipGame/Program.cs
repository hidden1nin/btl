﻿///////////////////////////////////////////////////////////////////////////////
//
// Author: James Letterman, lettermanj@etsu.edu
// Course: CSCI-2210-001 - Data Structures
// Assignment: Project 1, Battleship
// Description: This file runs the game from start to finish, I have added notes for each section to follow along.
//
///////////////////////////////////////////////////////////////////////////////
// See https://aka.ms/new-console-template for more information
using BattleShipGame;
using System.Reflection;

//Ask for a file to load;
Console.WriteLine("Welcome To Battleship!");
Console.WriteLine("Please enter the name of the file you want to play. Or hit enter to use the default map.");
String path = Console.ReadLine();

//Use a default file if none provided.
if (path == null || path == "") { Console.WriteLine("Using default file"); path = "Battleship-GoodData.gameboard"; }
string workingDirectory = Environment.CurrentDirectory;
path = Path.Combine(Directory.GetParent(workingDirectory).Parent.Parent.FullName, @"Data\", path+".txt");

//Load the ships into an array.
ShipFactory shipFactory = new ShipFactory();
var ships = shipFactory.ParseShipFile(path!);
if (ships.Length == 0) Console.WriteLine("Unable to load file.");


//Create the map and plot the ships onto it.
var map = new Ship[10,10];
if(!ShipFactory.plotShips(ships, map)) { return; }


//Start the main game loop, once it finishes the user has won.
while (ships.Length > 0) {
    Console.Clear();
    Console.WriteLine("Please enter the X of your shot");
    int X = Int32.Parse(Console.ReadLine());
    Console.WriteLine("Please enter the Y of your shot");
    int Y = Int32.Parse(Console.ReadLine());


    //If the map contains the ship then damage it and remove it if it has sunken.
    if (map[X, Y] is Ship) { 
        Ship ship = (Ship)map[X, Y];
        ship.TakeDamage(new Coord2D(X, Y));
        if (ship.IsDead())
        {
            var newShips = new List<Ship>();
            //TODO remove the ship from the ships array.
            foreach (Ship original in ships) {
                if (original.Equals(ship)) continue;
                newShips.Add(original);
            }
            ships = newShips.ToArray();
        }
        Console.WriteLine("Hit!");
        System.Threading.Thread.Sleep(1000);
    }
}

//Congratualate the user and pause for them.
Console.WriteLine("You Win!!");
Console.ReadLine();