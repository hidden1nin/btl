﻿///////////////////////////////////////////////////////////////////////////////
//
// Author: James Letterman, lettermanj@etsu.edu
// Course: CSCI-2210-001 - Data Structures
// Assignment: Project 1, Battleship
// Description: This file creates and helps initialize functionality relating to ships.
//
///////////////////////////////////////////////////////////////////////////////


using BattleShipGame.Types;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BattleShipGame
{
    internal class ShipFactory
    {
        /// <summary>
        /// Checks a given string as if its a valid ship.
        /// </summary>
        /// <param name="data">string to check</param>
        /// <returns>true or false of if it is viable.</returns>
        bool VerifyShipString(String data) {
            Regex rx = new Regex(@"(Carrier|Battleship|Destroyer|Submarine|Patrol Boat),\s*[0-9]+,\s(h|v|H|V),\s*[0-9]+,\s*[0-9]+\s*");
            return rx.IsMatch(data);
        }


        /// <summary>
        /// This creates a ship and returns it with all it's data filled in.
        /// </summary>
        /// <param name="data">Ship string from file</param>
        /// <returns>Fully Created ship, or null if a line contains an error.</returns>
        Ship ParseShipString(String data) {
            Ship? ship = null;
            var coords = new List<Coord2D>();
            var direction = data.Split(',')[2].Contains('h') ? Direction.Horizontal : Direction.Vertical;
            var size = int.Parse(data.Split(',')[1]);
            var x = int.Parse(data.Split(',')[3]);
            var y = int.Parse(data.Split(',')[4]);

            for (int i = 0; i < size; i++) {
                var coord = new Coord2D(direction == Direction.Horizontal ? x + i : x, direction == Direction.Vertical ? y + i:y);
                coords.Add(coord);
            }

            //If the ship cannot be created return null here.
            if (!VerifyShipString(data)) return ship;

            
            switch (data.Split(',')[0]) {
                case "Destroyer" : { 
                        ship = new Destroyer(coords.ToArray(), (Byte)size, direction); 
                        break; 
                    }
                case "Submarine" : {
                        ship = new Submarine(coords.ToArray(), (Byte)size, direction);
                        break;
                    }
                case "Carrier" : {
                        ship = new Carrier(coords.ToArray(), (Byte)size, direction);
                        break;
                    }
                case "Patrol Boat" : {
                        ship = new PatrolBoat(coords.ToArray(), (Byte)size, direction);
                        break;
                    }
                case "Battleship":
                    {
                        ship = new BattleShip(coords.ToArray(), (Byte)size, direction);
                        break;
                    }
            }
            return ship;
        }

        /// <summary>
        /// Creates a list of ships from a given textfile
        /// </summary>
        /// <param name="path">The text file path</param>
        /// <returns>Array of ships</returns>
        public Ship[] ParseShipFile(String path){
            var ships = new List<Ship>();
            if (!File.Exists(path)) return Array.Empty<Ship>();

            string[] lines = File.ReadAllLines(path);
            //Count what line the error is on aswell as if one occcured.
            var errorline = 0;
            var error = false;
            
            for (int i = 0; i < lines.Length; i++){
                string line = lines[i];
                //Ignores comments.
                if (line.StartsWith("#")) continue;
                var ship = ParseShipString(line);
                errorline = i;
                if (ship == null) { 
                    error = true;
                    break; 
                }
                ships.Add(ship);
             }
            if (error)
            {
                Console.WriteLine($"An error occurred while reading the file at line {errorline}.");
                return Array.Empty<Ship>();
            }
            return ships.ToArray();
        }

        /// <summary>
        /// This is a utility method that the main file uses to put the ships into a 2D array for easy access.
        /// </summary>
        /// <param name="ships">ships to plot</param>
        /// <param name="map">2D array to place the ships into.</param>
        /// <returns>True or false of if the ships can fit into the grid, this catches errors that happened in the text file.</returns>
        internal static bool plotShips(Ship[] ships, Ship[,] map)
        {
            try
            {
                foreach (Ship ship in ships)
                {
                    foreach (Coord2D coord in ship.Points)
                    {
                        map[coord.x, coord.y] = ship;
                    }
                }
            }
            catch {
                Console.WriteLine("This file cannot be mapped.");
                return false;
            }
            return true;
        }

    }
}
