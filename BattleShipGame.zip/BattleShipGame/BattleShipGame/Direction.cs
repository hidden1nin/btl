﻿///////////////////////////////////////////////////////////////////////////////
//
// Author: James Letterman, lettermanj@etsu.edu
// Course: CSCI-2210-001 - Data Structures
// Assignment: Project 1, Battleship
// Description: This file helps greatly with the creation of new ships allowing us to plot where they are.
//
///////////////////////////////////////////////////////////////////////////////


namespace BattleShipGame
{
    internal enum Direction
    {
        Vertical,
        Horizontal
    }
}
