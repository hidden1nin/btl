﻿///////////////////////////////////////////////////////////////////////////////
//
// Author: James Letterman, lettermanj@etsu.edu
// Course: CSCI-2210-001 - Data Structures
// Assignment: Project 1, Battleship
// Description: This file is the Battleship class and represents the Battleship in memory.
//
///////////////////////////////////////////////////////////////////////////////


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BattleShipGame.Types
{
    internal class BattleShip : Ship
    {
        public BattleShip(Coord2D[] points, byte length, Direction direction) : base(points, length, direction)
        {

        }
        
    }
}
