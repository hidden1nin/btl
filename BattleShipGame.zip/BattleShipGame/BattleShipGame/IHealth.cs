﻿///////////////////////////////////////////////////////////////////////////////
//
// Author: James Letterman, lettermanj@etsu.edu
// Course: CSCI-2210-001 - Data Structures
// Assignment: Project 1, Battleship
// Description: This file ensures each ship has a standardized set of methods for handling it's health.
//
///////////////////////////////////////////////////////////////////////////////


namespace BattleShipGame
{
    internal interface IHealth
    {
        int GetMaxHealth();
        int GetCurrentHealth();
        bool IsDead();
        void TakeDamage(int damage);
        void TakeDamage(Coord2D location);
    }
}
