﻿///////////////////////////////////////////////////////////////////////////////
//
// Author: James Letterman, lettermanj@etsu.edu
// Course: CSCI-2210-001 - Data Structures
// Assignment: Project 1, Battleship
// Description: This file is the standard unit each ship uses to mark where it is placed.
//
///////////////////////////////////////////////////////////////////////////////

namespace BattleShipGame
{
    public struct Coord2D
    {
        public int x;
        public int y;
        public Coord2D(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
    }
}
