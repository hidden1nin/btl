﻿///////////////////////////////////////////////////////////////////////////////
//
// Author: James Letterman, lettermanj@etsu.edu
// Course: CSCI-2210-001 - Data Structures
// Assignment: Project 1, Battleship
// Description: This file makes sure each ship can have a description since they implement it.
//
///////////////////////////////////////////////////////////////////////////////

namespace BattleShipGame
{
    internal interface IInformatic
    {
        String GetInfo();
    }
}
