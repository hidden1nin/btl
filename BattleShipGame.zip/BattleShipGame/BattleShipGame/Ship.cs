﻿///////////////////////////////////////////////////////////////////////////////
//
// Author: James Letterman, lettermanj@etsu.edu
// Course: CSCI-2210-001 - Data Structures
// Assignment: Project 1, Battleship
// Description: This file sets the base functionality for ships, it gives us a base expectation of what each ship file is capable of.
//
///////////////////////////////////////////////////////////////////////////////


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BattleShipGame
{
    abstract internal class Ship : IHealth,IInformatic
    {
        public Coord2D[] Points { get; set; }
        public Byte length { get; set; }
        public Direction direction { get; set; }
        public Coord2D[] DamagedPoints {get; set; }


        /// <summary>
        /// Creation method for the ships.
        /// </summary>
        public Ship(Coord2D[] points, byte length, Direction direction)
        {
            Points = points;
            this.length = length;
            this.direction = direction;
            DamagedPoints = new Coord2D[length];
        }


        //Below are the overrides that are inherited from other classes.

        public int GetMaxHealth()
        {
            return length;
        }

        public int GetCurrentHealth()
        {
            return Points.Length;
        }

        public bool IsDead()
        {
            return length==DamagedPoints.Length;

        }

        [Obsolete]
        public void TakeDamage(int damage)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// This method moves a coord2d from list points to list damaged points.
        /// </summary>
        /// <param name="location"></param>
        public void TakeDamage(Coord2D location)
        {
            var newPoints = new List<Coord2D>();
            foreach (Coord2D coord in Points) {
                if (coord.Equals(location)) continue;
                newPoints.Add(coord);
            }
            if (newPoints.ToArray().Length == Points.Length) {
                Console.WriteLine("You have already damaged this coordinate!");
                return;
            }
            Points = newPoints.ToArray();
            var newDamaged = DamagedPoints.ToList();
            newDamaged.Add(location);
            DamagedPoints = newDamaged.ToArray();
        }

        public string GetInfo()
        {
            return "";
        }
    }
}
